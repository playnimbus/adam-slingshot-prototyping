﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class ISN_PurchaseAction : FsmStateAction {


		[Tooltip("Event fired when Store Kit purchase is complete")]
		public FsmEvent successEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;


		[Tooltip("Purhase product Id")]
		public string ProductID  = "";


		[UIHint(UIHint.Variable)]
		public FsmString receipt;

		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			new IOSBillingInitChecker(OnBillingInit);

		}

		private void OnBillingInit() {
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);
			IOSInAppPurchaseManager.instance.buyProduct(ProductID);
		}

		private void OnPurchase(CEvent e) {
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);


			IOSStoreKitResponse resp = e.data as IOSStoreKitResponse;
			receipt.Value = resp.receipt;

			Fsm.Event(successEvent);
			Finish();

		}

		private void OnFailed() {
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);

			Fsm.Event(failEvent);
			Finish();

		}
		
	}
}
