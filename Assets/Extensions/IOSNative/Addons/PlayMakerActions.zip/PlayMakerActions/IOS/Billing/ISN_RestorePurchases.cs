using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Restore purchases, resotred event will be fired for ectach restored purchase")]
	public class ISN_RestorePurchases : FsmStateAction {
		
				
		[UIHint(UIHint.Variable)]
		public FsmString restoredProductId;

		[Tooltip("Event fired when Store Kit product restored")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;
		


		public override void Reset() {
			restoredProductId = null;
		}


		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);
			
		}

		private void OnBillingInit() {
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_FAILED, OnFailed);
			IOSInAppPurchaseManager.instance.restorePurchases();
		}


		private void OnPurchase(CEvent e) {

			IOSStoreKitResponse resp = e.data as IOSStoreKitResponse;
			restoredProductId.Value =  resp.productIdentifier;
			
			Fsm.Event(successEvent);

			
		}
		
		private void OnFailed() {
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);
			
			Fsm.Event(failEvent);
			Finish();
			
		}
		
	}
}




