﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - iAd")]
	public class ISN_LoadInterstisialAd : FsmStateAction {

		[Tooltip("Event fired when Ad is started")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Ad is failed to load")]
		public FsmEvent failEvent;

		public override void OnEnter() {
			iAdBannerController.instance.LoadInterstitialAd();
			iAdBannerController.instance.addEventListener(iAdEvent.INTERSTITIAL_AD_DID_LOAD, OnReady);
			iAdBannerController.instance.addEventListener(iAdEvent.INTERSTITIAL_DID_FAIL_WITH_ERROR, OnFail);

		}


		private void OnReady() {

			iAdBannerController.instance.removeEventListener(iAdEvent.INTERSTITIAL_AD_DID_LOAD, OnReady);
			iAdBannerController.instance.removeEventListener(iAdEvent.INTERSTITIAL_DID_FAIL_WITH_ERROR, OnFail);

			Fsm.Event(successEvent);
			Finish();
		}

		private void OnFail() {

			iAdBannerController.instance.removeEventListener(iAdEvent.INTERSTITIAL_AD_DID_LOAD, OnReady);
			iAdBannerController.instance.removeEventListener(iAdEvent.INTERSTITIAL_DID_FAIL_WITH_ERROR, OnFail);

			Fsm.Event(failEvent);
			Finish();
		}
		
	}
}
